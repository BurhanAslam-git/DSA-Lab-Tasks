#include<iostream>
#include<string>
using namespace std;

class FamilyMember{
    private:
        string name;
        double* ptr;
        int numCategories;
        double totalExpenses;

    public:

        FamilyMember() {}
        FamilyMember(string name, int numCategories, double* exp){
            this->name = name;
            this->numCategories = numCategories;   
            this->ptr = new double[numCategories];
            for(int i=0 ;i<numCategories; ++i){
                ptr[i] = exp[i];
            }
            totalExpenses = 0;
        }

        void  TotalExpenses(){
            for(int i=0; i<numCategories; ++i){
                totalExpenses += ptr[i];
            }
        }

        // getters;


        string getName(){
            return this->name;
        }

        double getTotalExp(){
            return totalExpenses;
        }

        int getNumCatogories(){
            return this->numCategories;
        }

        double averageExp(){
            return (totalExpenses) / (this->numCategories);
        }

        void display(){
            for(int i=0; i<numCategories; ++i){
                cout << ptr[i] << " ";
            }
        }

        ~FamilyMember(){
            delete[] ptr;
        }

};


int main(){
    int FamMembers;
    cout << "\nEnter the Number of Family Members : "; cin >> FamMembers;
    while(FamMembers <= 0){
        cout << "Invalid \n Enter again : "; cin >> FamMembers;
    }

    FamilyMember* member = new FamilyMember[FamMembers];

    for(int i=0; i<FamMembers; ++i){
        string name;
        int numCategories;
        cout << "\nEnter Family Member # " << i+1 << " details : ";
        cin.ignore();
        cout << "\nEnter Name : "; getline(cin, name);
        cout << "\nEnter Number of Categories : "; cin >> numCategories;
        while (numCategories <= 0){
            cout << "Invalid \n Enter again : "; cin >> numCategories;
        }
        double* exp = new double[numCategories];
        for(int i=0; i<numCategories; ++i){
            cout << "Enter expense value for cateogor # " << i+1 << " : ";
            cin >> exp[i];
        }
        member[i] = FamilyMember(name, numCategories, exp);

        delete[] exp;

    }

    cout << "Each Family Member Total Expense " << endl;
    double totalFamExp = 0;
    for(int i=0; i<FamMembers; ++i){
        cout << "Family Memeber # " << i+1 << " : ";
        cout << "Name ==> " << member[i].getName() << endl;
        cout << "Exp Category : " << member[i].getNumCatogories() << endl;
        cout << "Exp Per Category : " << endl;
        member[i].display();
        member[i].TotalExpenses();
        cout << "Total Expenses : " << member[i].getTotalExp() << endl;
        cout << "Average Expenses : " << member[i].averageExp() << endl;
        totalFamExp += member[i].getTotalExp();
    }

    cout << "Total Family Expense ===> " << totalFamExp << endl;

    delete[] member;

}
