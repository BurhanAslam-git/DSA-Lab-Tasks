#include<iostream>
#include<string>
using namespace std;


class Book{
    private:
        string title;
        string author;
        double price;
        

    public:

    int c;

    Book() {}

    // for fiction book.
   Book(string a, string t, double p){
    this->title = t;
    this->author = a;
    this->price = p;
    this->c = 1;
   }

    // for non - fiction book.
   Book(string t, string a){
    this->title = t;
    this->author = a;
    this->price = 0;
    this->c = 2;
   }

// setters;


   void setPrice(double p){
    this->price = p;
   }

   void setTitile(string t){
    this->title = t;
   }

   void setAuthor(string a){
    this->author = a;
   }

   // getters;

   string getTitle(){
    return this->title;
   }

    string getAuthor(){
        return this->author;
    }

       double getPrice(){
    return this->price;
   }


};


class Library{
    private:
        Book book;
        double discount;

    public:
        Library(Book &b){
            this->book = b;
        }

        // calculating and assigning discount.
        void calcDiscount(Book &b){
            this->discount = b.getPrice() * (0.1);
            b.setPrice(b.getPrice() - this->discount);

        }

    void display(Book &b){

        cout << "\n============BOOK DETAILS=====================\n\n";
        cout << "Book Title ====> " << b.getTitle() << endl;
        cout << "Book Author ====> " << b.getAuthor() << endl;
        if(b.c == 1){
            calcDiscount(b);
            cout << "Book price after discount ====> " << b.getPrice() << endl;
        }
        else if (b.c == 2){
            cout << "Book Price ===> " << b.getPrice() << endl;
        }
       
    }
    
};

int main(){
    int c1;
    cout << "Enter the type of the Book (Fiction/Non Fiction) \n\n"
            "Press 1 ==> for Fiction Book \n" 
            "Press 2 ==> for Non - Fiction Book \n";
    cout << "Enter your choice : "; cin >> c1;
    while(c1 != 1 && c1 != 2){
        cout << "Invalid \n Enter again ";  cin >> c1;
    }

    string t, a;
     double p;

    cin.ignore();

    if(c1 == 1){
        cout << "Enter the author name "; getline(cin,a);
        cout << "Enter the title of the Book : "; getline(cin,t);
        cout << "Enter the Price of the book : "; cin >> p;
        Book b1(a,t,p);
        Library l1(b1);
        l1.display(b1);
    }


    else if (c1 == 2){
        cout << "Enter the author name "; getline(cin,a);
        cout << "Enter the title of the Book : "; getline(cin,t);
        cout << "Enter the Price of the book : "; cin >> p;
        Book b2(a,t);
        b2.setPrice(p);
        Library l2(b2);
        l2.display(b2);
    }
    return 0;
}