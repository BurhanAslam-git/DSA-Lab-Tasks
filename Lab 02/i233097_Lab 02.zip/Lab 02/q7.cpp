#include<iostream>
using namespace std;

template<typename T, size_t Size>
class GenericContainer{
    private:
        T elements[Size];
        size_t count;
 
    public:
        GenericContainer() : count(0) {}

        void addElement(const T& element){
            if(count < 5){
                elements[count++] = element;
            }
        }

        void removeElement(const T& element){
            for(int i=0; i<count; ++i){
                if(elements[i] == element){
                    for(int j = i; j<count; ++j){
                        elements[j] = elements[j+1];
                    }
                    count--;
                    return;
                }
            }
        }

        void displayElements() const{
            for(int i=0; i<count; ++i){
                cout << elements[i] << "  ";
            }
            cout << endl;
        }

};


int main(){
    GenericContainer<int,5> intContainer;
    intContainer.addElement(5);
    intContainer.addElement(10);
    intContainer.addElement(3);
    intContainer.displayElements();
    intContainer.removeElement(10);
    intContainer.displayElements();

    // with strings.
    GenericContainer<string,5> stringContainer;
    stringContainer.addElement("apple");
    stringContainer.addElement("banana");
    stringContainer.addElement("orange");
    stringContainer.displayElements();
    stringContainer.removeElement("banana");
    stringContainer.displayElements();

    return 0;
}