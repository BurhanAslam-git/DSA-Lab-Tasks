#include<iostream>
using namespace std;

class GameInventory {
private:
    int games[100];
    static int count;

public:

    // function to add the game based on the gameId and the location.
    void addGame(int gameId, int loc) {
        if (!(loc < 100 && loc >= 0)) {
            cout << "Invalid Location Entered!" << endl;
            return;
        }
        if (count < 100) {
            games[loc] = gameId;
            count++;
        } else {
            cout << "Oops! Inventory is FULL!" << endl;
            return;
        }
    }

    // function to remove a game from a specific location
    void removeGame(int loc) {
        if (!(loc < 100 && loc >= 0)) {
            cout << "Invalid Location Entered!" << endl;
            return;
        }
        for (int i = (loc-1); i < count - 1; ++i) {
            games[i] = games[i + 1];
        }
        count--;
    }

    // function to search a game by its ID
    void searchGame(int gameId) {
        for (int i = 0; i < count; ++i) {
            if (games[i] == gameId) {
                cout << "Game Found!" << endl;
                return;
            }
        }
        cout << "Game NOT Found!" << endl;
    }

    // function to update a game ID at a given location
    void updateGameInfo(int id, int loc) {
        if (!(loc < 100 && loc >= 0)) {
            cout << "Invalid Location Entered!" << endl;
            return;
        }
        games[loc] = id;  // updating the game ID
        cout << "Updated!" << endl;
    }

    // function to display all games in the inventory
    void displayGame(void) const {
        cout << "\n\n====Details=====\n";
        for (int i = 0; i < count; ++i) {
            cout << games[i] << "  ";
        }
        cout << endl;
    }
};

int GameInventory::count = 0;

int main() {
    GameInventory inventory;

    cout << "Step 1: Adding games to the inventory.\n";
    inventory.addGame(101, 0); 
    inventory.addGame(102, 1);
    inventory.addGame(103, 2); 
    inventory.displayGame();

    cout << "\nStep 2: Removing game at position 1.\n";
    inventory.removeGame(1);
    inventory.displayGame();


    cout << "\nStep 3: Searching for game ID 103.\n";
    inventory.searchGame(103);


    cout << "\nStep 4: Updating game ID at position 0 to 200.\n";
    inventory.updateGameInfo(200, 0);
    inventory.displayGame();


    cout << "\nStep 5: Viewing the inventory.\n";
    inventory.displayGame();

    return 0;
}
