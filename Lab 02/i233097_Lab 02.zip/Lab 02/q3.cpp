#include<iostream>
using namespace std;

// Template with variable argument.
template<typename... Args>
void countArgs(Args... a){
    cout << "\nNumber of Arguments is ===> " << sizeof...(a) << endl;
}

int main(){
    countArgs(1, 2.5, "Hello", 'A');  
    countArgs(10, 20);     
    countArgs(1);         
    cout << "\nProgram has Ended !";  
    return 0;
}
