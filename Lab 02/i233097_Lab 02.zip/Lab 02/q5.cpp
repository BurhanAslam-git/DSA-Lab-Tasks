#include<iostream>
using namespace std;

template<typename T>
void print(T arr[], int s){
    for(int i=0; i<s; ++i){
        cout << arr[i] << "  ";
    }
}

// specilization for char array.
template <>
void print<char>(char v[], int s){
    cout << v << endl;
}


int main(){
    int arr[] = {1,2,3,4}; // integer array.
    print(arr,4);

    cout << "\nPrinting the Entire Character Array : \n";
    char arr1[] = "Burhan";
    print(arr1,6); 
    return 0;
}