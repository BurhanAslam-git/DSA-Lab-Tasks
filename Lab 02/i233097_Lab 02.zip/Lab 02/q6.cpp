#include<iostream>
using namespace std;

template<typename T>
int getSize(){
    return sizeof(T);
}


int main(){
    cout << "Size of int : "  << getSize<int>() << " bytes" << endl;
    cout << "Size of double : "  << getSize<double>() << " bytes" <<  endl;
    cout << "Size of char : "  << getSize<char>() <<  " bytes" <<  endl;
}