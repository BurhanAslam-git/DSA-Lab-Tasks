#include<iostream>
using namespace std;

template <typename T>
T findMax(T a, T b){
    T larger;
    if(a > b){
        larger = a;
    }
    else{
        larger = b;
    }
    return larger;
}

int main(){
    cout << "Maximum Value of 5 and 7 is : " << findMax(5,7) << endl;
    cout << "Maximum Value of 4.5 and 2.3 is : " << findMax(4.5,2.3) << endl;
    cout << "Maximum Value of apple and banana is : " << findMax(string("apple"),string("banana")) << endl;

      cout << "\nProgram has Ended !"; 
    return 0;
}