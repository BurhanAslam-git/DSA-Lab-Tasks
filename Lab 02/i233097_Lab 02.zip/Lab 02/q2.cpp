#include<iostream>
using namespace std;

template <typename T>
T findMax(T a, T b) {
    T larger;
    if(a>b){
        larger = a;
    }
    else{
        larger = b;
    }
    return larger;
}

// Overloading for three arguments.
template <typename T>
T findMax(T a, T b, T c) {
    T large;
    if(a > b){
        large = a;
        if(a > c){
            large = a;
        }
        else{
            large = c;
        }
    }
    else{
        if(b > c){
            large = b;
        }
        else{
            large = c;
        }
    }
    return large;
    
}

int main() {
    cout << "\n==============For Integers==================\n";
    cout << "Maximum of 5 & 10 is : " << findMax(5,10);
    cout << "\n================================\n";
    cout << "\n==============For Floating-Point Numbers==================\n";
    cout << "Maximum of 10.5, 15.5 & 20.5 is : " << findMax(10.5,15.5,20.5);

      cout << "\n\nProgram has Ended !"; 

    return 0;
}