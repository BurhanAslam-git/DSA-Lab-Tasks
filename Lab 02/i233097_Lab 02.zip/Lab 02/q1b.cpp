#include<iostream>
using namespace std;

template<typename T>
void swapValues(T a, T b){
    cout << "Before Swapping : "<< endl;
    cout << "a : " << a << endl;
    cout << "b : " << b <<  endl;
    T temp;
    temp = a;
    a = b;
    b = temp;
    cout << "After Swapping : " << endl;
    cout << "a : " << a << endl;
    cout << "b : " << b <<  endl;
}

int main(){
    double p = 3.14, q = 2.71;
    string s1 = "Hello", s2 = "World";
    cout << "\n";

    swapValues(10,20);
    cout << "=====================================\n\n";

    swapValues(3.14,2.71);
    cout << "=====================================\n\n";


    swapValues("Hello","World");
    cout << "=====================================\n\n";

      cout << "\nProgram has Ended !"; 

    return 0;
}