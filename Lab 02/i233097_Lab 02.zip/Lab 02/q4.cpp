#include<iostream>
using namespace std;

template<typename T = int> // default is int.
T findMin(T a = 15, T b = 20){ // use a = 15, b = 20 as default.
    T smaller;
    if(a < b){
        smaller = a;
    }
    else{
        smaller = b;
    }
    return smaller;
}

int main(){
    cout << "Minimun of 10 & 15 : "  << findMin(10,15) << endl; 
    cout << "Minimun of 10.5 & 15.5 : "  << findMin(10.5,15.5) << endl; 
    cout << "Minimun of 'a' & 'b' : "  << findMin('a','b') << endl; 
    cout << "Minimun of 15 & 20 : "  << findMin() << endl;
    return 0;
}
