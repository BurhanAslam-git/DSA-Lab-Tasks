#include<iostream>
using namespace std;

class Anomalies{
    private:
        double* temp;
        int n;

    public:
        Anomalies(){
            temp = nullptr;
            n = 0;
        }

        // Function to set temperature readings
        void setTemp(int n){
            temp = new double[n]; // Dynamically allocate memory for temperature readings
            this->n = n;
            for(int i=0; i<n; ++i){
                cout << "Enter temperature Reading for " << i+1 << " ---> ";
                cin >> temp[i];
                while(temp[i] < 0){
                    cout << "Invalid \n Enter 0 or greater than 0: ";
                    cin >> temp[i]; 
                }
            }
        }

        // Bubble sort to sort the temperature readings
        void sortTemp(){
            cout << "\n========SORTING USING BUBBLE SORT===========\n";
            bool isSwapped = false;
            for(int i = n-1; i>=1; --i){ // outer loop
                for(int j=0; j<=i-1; ++j){ // inner loop.
                    if(temp[j] > temp[j+1]){
                        swap(temp[j], temp[j+1]);
                        isSwapped = true;
                    }
                }   
                if(isSwapped == false){
                    break;
                }
            }
            cout << "Displaying the Sorted array  ---> "; 
            for(int i=0; i<n; ++i){
                cout << temp[i] << "  ";
            }
            cout << "\nTemperatures sorted successfully.\n";
        }

        // Iterative approach using Binary Search
        void checkTemp1(double t){
            int start = 0;
            int end = n - 1;
            bool isfound = false;
            int middle;
            int comp = 0;
            while(!isfound && start <= end){
                ++comp;
                middle = (start + end)/2;
                if(temp[middle] == t){
                    isfound = true;
                    cout << "Temperature Recorded at Index " << middle << endl;
                    break;
                }
                else if(temp[middle] > t){
                    end = middle - 1;
                }
                else{
                    start = middle + 1;
                }
            }
            if(!isfound){
                cout << "\nTemperature NOT Recorded!" << endl;
            }
            cout << "\n\nNumber of Comparisons Made is ----> " << comp << endl;
        }

        // Recursive approach using Binary Search
        void checkTemp2(double t, int start, int end, int comp){
            if (start > end) {
                cout << "\nTemperature NOT Recorded!" << endl;
                cout << "\n\nNumber of Comparisons Made is ----> " << comp << endl;
                return;
            }

            int middle = (start + end) / 2;
            ++comp;

            if (temp[middle] == t) {
                cout << "Temperature Recorded at Index " << middle << endl;
                cout << "\n\nNumber of Comparisons Made is ----> " << comp << endl;
                return;
            }
            else if (temp[middle] > t) {
                checkTemp2(t, start, middle - 1, comp); 
            }
            else {
                checkTemp2(t, middle + 1, end, comp); 
            }
        }

        // Function to call either the iterative or recursive search
        void checkTemp(double t){
            int choice;
            cout << "\nChoose search method: \n1. Iterative Approach\n2. Recursive Approach\nEnter your choice: ";
            cin >> choice;
            while((choice != 1) && (choice != 2)){
                cout << "Enter 1 or 2 NOT other than this \n Enter again (1 - 2) : ";
                cin >> choice;
            }

            if(choice == 1){
                checkTemp1(t);  // Iterative approach
            } else if(choice == 2){
                checkTemp2(t, 0, n-1, 0); // Recursive approach, starting with the full range
            } else {
                cout << "Invalid choice!" << endl;
            }
        }


        ~Anomalies(){
            delete[] temp; 
        }
};

int main(){
    int n;
    cout << "Enter the number of temperature readings you want to set: ";
    cin >> n;
    while(n <= 0){
        cout << "Invalid input! Enter a number greater than 0: "; 
        cin >> n;
    }

    Anomalies a1;
    a1.setTemp(n);

    double target;
    cout << "\nEnter the target Temperature you want to search for: ";
    cin >> target;
    while(target < 0){
        cout << "Enter again (must be greater than or equal to 0): ";
        cin >> target;
    }

    a1.sortTemp();
    a1.checkTemp(target);  // Call the checkTemp method that asks for user's choice

    return 0;
}
