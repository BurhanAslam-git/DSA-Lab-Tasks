#include<iostream>
using namespace std;

class Component {
    private:
        string* comp_name;
        int* serial_number;
        int* status_flag;
        int number;

    public:
        Component() {
            comp_name = nullptr;
            serial_number = nullptr;
            status_flag = nullptr;
        }
        void setSerialNumber(int);
        void setStatusFlag(int);
        void display(void);
        void displayStatus(int no);
};

void Component::setSerialNumber(int n) {
    number = n;
    serial_number = new int[n]; 
    for (int i = 0; i < n; ++i) {
        serial_number[i] = i + 1; // Set serial number
    }
    
    comp_name = new string[n];
    for (int i = 0; i < n; ++i) {
        cout << "Enter Component Name " << i + 1 << " --> ";
        cin >> comp_name[i]; // Input component name
    }
}

void Component::setStatusFlag(int n) {
    // Dynamically allocate memory for status flags
    status_flag = new int[n]; // For status flags
    for (int i = 0; i < n; ++i) {
        cout << "Enter Status for Component " << i + 1 << " (0 for faulty and 1 for working): ";
        cin >> status_flag[i]; // Input status flag
        while(status_flag[i] != 0 || status_flag[i] != 1){
            cout << "Enter between 0 - 1 not other than this : ";
            cin >> status_flag[i];
        }
    }
}

void Component::display(void){
    cout << "\n\n========================================\n\n";
    for(int i=0; i<number; ++i){
        cout << "Serial Number ---> " << *(serial_number + i) << endl;
        cout << "Component Name ---> " << *(comp_name + i) << endl;
        cout << "Status Flag ---> " << *(status_flag + i) << endl;
    }
}

void Component::displayStatus(int no){
    int comp = 0;
    bool isfound = false;
    for(int i=0; i<number; ++i){
        ++comp;
        if(*(serial_number + i) == no){
            isfound = true;
            cout << "Component Found !"<< endl;
            cout << "Component Name ---> "<< *(comp_name + i) << endl;
            cout << "Status Flag ---> "<< *(status_flag + i) << endl;
            break;
        }
    }
    if(!isfound){
        cout << "Component NOT Found !" << endl;
    }
    cout << "\n\nNumber of Comparison are ---> " << comp << endl; 
}

int main() {
    int n;
    cout << "\nEnter the Number of Components for the factory: ";
    cin >> n;
    while (n <= 0) {
        cout << "Invalid input! Enter again: ";
        cin >> n;
    }
    int no;
    Component comp;
    comp.setSerialNumber(n);
    comp.setStatusFlag(n);
    comp.display();

    cout << "\nEnter the serial number you want to search : "; cin >>no;
    while(no <= 0){
        cout << "Invalid \n Enter again : "; cin >> no;
    }
    comp.displayStatus(no);

        return 0;
    }
    
