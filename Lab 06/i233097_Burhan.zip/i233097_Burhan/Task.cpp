#include<iostream>
#include<string>
using namespace std;

struct Patient {
    int patientID;       
    string name;         
    int severity;        
    string arrivalTime;  
    
    Patient(int id, string n, int sev, string time)
        : patientID(id), name(n), severity(sev), arrivalTime(time) {}
};

struct Node {
    Patient patient;   
    Node* next;        
    
    Node(Patient p) : patient(p), next(nullptr) {}
};


class EmergencyQueue {
private:
    Node* head;  
    
public:
    EmergencyQueue() : head(nullptr) {}

    // Function to add a patient at the beginning (Critical patient)
    void insertAtHead(Patient p) {
        Node* newNode = new Node(p);
        newNode->next = head;
        head = newNode;
    }

    // Function to add a patient at the end (Normal patient)
    void insertAtTail(Patient p) {
        Node* newNode = new Node(p);
        if (head == nullptr) {
            head = newNode;
            return;
        }
        
        Node* temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode;
    }

    // Function to insert a patient at a specific position based on severity and arrival time
    void insertAtPosition(Patient p, int position) {
        if (position < 1) return;  // Invalid position
        
        if (position == 1) {
            insertAtHead(p);
            return;
        }
        
        Node* newNode = new Node(p);
        Node* temp = head;
        
        // Traverse to the node just before the given position
        for (int i = 1; temp != nullptr && i < position - 1; i++) {
            temp = temp->next;
        }
        
        if (temp == nullptr) return;  // Position out of bounds     
        newNode->next = temp->next;
        temp->next = newNode;
    }

    // Function to delete a patient at the beginning (Discharge the first patient)
    void deleteAtHead() {
        if (head == nullptr) return;  // List is empty
        
        Node* temp = head;
        head = head->next;
        delete temp;
    }

    // Function to delete a patient at the end (If they leave without treatment)
    void deleteAtTail() {
        if (head == nullptr) return;  // List is empty
        
        if (head->next == nullptr) {  // If there's only one patient
            delete head;
            head = nullptr;
            return;
        }
        
        Node* temp = head;
        while (temp->next != nullptr && temp->next->next != nullptr) {
            temp = temp->next;
        }
        
        delete temp->next;  // Delete the last patient
        temp->next = nullptr;
    }

    // Function to delete a specific patient by ID (Transferred to another hospital)
    void deleteByID(int patientID) {
        if (head == nullptr) return;  // List is empty
        
        if (head->patient.patientID == patientID) {  // If the patient to be deleted is at the head
            Node* temp = head;
            head = head->next;
            delete temp;
            return;
        }
        
        Node* temp = head;
        while (temp->next != nullptr && temp->next->patient.patientID != patientID) {
            temp = temp->next;
        }
        
        if (temp->next == nullptr) return;  // Patient ID not found
        
        Node* nodeToDelete = temp->next;
        temp->next = temp->next->next;
        delete nodeToDelete;
    }

    // Function to search for a patient by ID
    Node* searchByID(int patientID) {
        Node* temp = head;
        while (temp != nullptr) {
            if (temp->patient.patientID == patientID) {
                return temp;
            }
            temp = temp->next;
        }
        return nullptr;
    }

    // Function to display the entire list of patients
    void display() {
        Node* temp = head;
        while (temp != nullptr) {
            cout << "ID: " << temp->patient.patientID
                 << ", Name: " << temp->patient.name
                 << ", Severity: " << temp->patient.severity
                 << ", Arrival: " << temp->patient.arrivalTime << endl;
            temp = temp->next;
        }
    }

    // Destructor to clean up the memory
    ~EmergencyQueue() {
        while (head != nullptr) {
            deleteAtHead();
        }
    }
};

int main() {
    EmergencyQueue queue;

    
    Patient p1(104, "Dave", 5, "10:15 AM");
    Patient p2(101, "Alice", 2, "10:00 AM");
    Patient p3(102, "Bob", 3, "10:05 AM");
    Patient p4(103, "Charlie", 1, "10:10 AM");
    Patient p5(105, "Eve", 4, "10:20 AM");

   
    queue.insertAtTail(p1);  
    queue.insertAtTail(p2);  
    queue.insertAtTail(p3);  
    queue.insertAtHead(p4);  
    queue.insertAtPosition(p5, 2);  

    cout << "Initial Patient List: " << endl;
    queue.display();

    
    int searchID = 102;
    Node* found = queue.searchByID(searchID);
    if (found) {
        cout << "\nSearching for Patient ID " << searchID << ": Found - " << found->patient.name << endl;
    }

 
    queue.deleteAtHead();  
    cout << "\nAfter discharging the first patient: " << endl;
    queue.display();

    queue.deleteAtTail();  
    cout << "\nAfter removing last patient: " << endl;
    queue.display();

    queue.deleteByID(102);  
    cout << "\nAfter transferring patient ID 102: " << endl;
    queue.display();


    return 0;
}
