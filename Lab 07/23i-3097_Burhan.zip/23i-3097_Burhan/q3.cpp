#include <iostream>
using namespace std;

// Node structure for circular linked list
struct Node {
    int data;
    Node* next;
};

// Class for Circular Linked List
class CircularLinkedList {
public:
    Node* head;

    // Constructor to initialize an empty list
    CircularLinkedList() {
        head = nullptr;
    }

    // Function to insert a node at the end of the list
    void insertAtEnd(int value) {
        Node* newNode = new Node();
        newNode->data = value;
        if (head == nullptr) {
            head = newNode;
            newNode->next = head; // Point to itself, forming a circle
        } else {
            Node* temp = head;
            while (temp->next != head) {
                temp = temp->next;
            }
            temp->next = newNode;
            newNode->next = head;  // New node points to the head, forming a circle
        }
    }

    // Function to insert a node at the beginning (head) of the list
    void insertAtHead(int value) {
        Node* newNode = new Node();
        newNode->data = value;
        if (head == nullptr) {
            head = newNode;
            newNode->next = head;
        } else {
            Node* temp = head;
            while (temp->next != head) {
                temp = temp->next;
            }
            temp->next = newNode;
            newNode->next = head;
            head = newNode; // New node becomes the head
        }
    }

    // Function to insert a node at a specific position
    void insertAtPosition(int value, int position) {
        if (position < 1) {
            cout << "Invalid position!" << endl;
            return;
        }

        Node* newNode = new Node();
        newNode->data = value;

        if (position == 1) {
            insertAtHead(value);
            return;
        }

        Node* temp = head;
        int count = 1;
        while (count < position - 1 && temp->next != head) {
            temp = temp->next;
            count++;
        }

        if (temp->next == head && count < position - 1) {
            cout << "Position out of range!" << endl;
            delete newNode;
            return;
        }

        newNode->next = temp->next;
        temp->next = newNode;
    }

    // Function to traverse the list
    void traverse() {
        if (head == nullptr) {
            cout << "List is empty!" << endl;
            return;
        }

        Node* temp = head;
        do {
            cout << temp->data << " ";
            temp = temp->next;
        } while (temp != head);
        cout << endl;
    }

    // Function to delete a node from the beginning (head)
    void deleteFromBeginning() {
        if (head == nullptr) {
            cout << "List is empty!" << endl;
            return;
        }

        if (head->next == head) { // Only one node in the list
            delete head;
            head = nullptr;
        } else {
            Node* temp = head;
            Node* last = head;
            while (last->next != head) {
                last = last->next;
            }
            head = head->next;
            last->next = head;
            delete temp;
        }
    }

    // Function to delete a node from the end of the list
    void deleteFromEnd() {
        if (head == nullptr) {
            cout << "List is empty!" << endl;
            return;
        }

        Node* temp = head;
        if (head->next == head) { // Only one node in the list
            delete head;
            head = nullptr;
        } else {
            Node* prev = nullptr;
            while (temp->next != head) {
                prev = temp;
                temp = temp->next;
            }
            prev->next = head;
            delete temp;
        }
    }

    // Function to delete a node from a specific position
    void deleteAtPosition(int position) {
        if (head == nullptr || position < 1) {
            cout << "Invalid position or list is empty!" << endl;
            return;
        }

        if (position == 1) {
            deleteFromBeginning();
            return;
        }

        Node* temp = head;
        Node* prev = nullptr;
        int count = 1;

        while (temp->next != head && count < position) {
            prev = temp;
            temp = temp->next;
            count++;
        }

        if (count == position) {
            prev->next = temp->next;
            delete temp;
        } else {
            cout << "Position out of range!" << endl;
        }
    }

    // Function to find the length of the circular linked list
    int length() {
        if (head == nullptr) {
            return 0;
        }

        int count = 1;
        Node* temp = head;
        while (temp->next != head) {
            count++;
            temp = temp->next;
        }
        return count;
    }
};

int main() {
    CircularLinkedList cll;
    int choice, value, position;

    do {
        cout << "\nMenu:\n";
        cout << "1. Insert at the beginning (Head)\n";
        cout << "2. Insert at the end\n";
        cout << "3. Insert at a specific position\n";
        cout << "4. Delete from the beginning (Head)\n";
        cout << "5. Delete from the end\n";
        cout << "6. Delete from a specific position\n";
        cout << "7. Traverse (Display all calls)\n";
        cout << "8. Find the length of the Circular Linked List\n";
        cout << "9. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value to insert at the beginning: ";
                cin >> value;
                cll.insertAtHead(value);
                break;
            case 2:
                cout << "Enter value to insert at the end: ";
                cin >> value;
                cll.insertAtEnd(value);
                break;
            case 3:
                cout << "Enter value to insert and position: ";
                cin >> value >> position;
                cll.insertAtPosition(value, position);
                break;
            case 4:
                cll.deleteFromBeginning();
                break;
            case 5:
                cll.deleteFromEnd();
                break;
            case 6:
                cout << "Enter position to delete from: ";
                cin >> position;
                cll.deleteAtPosition(position);
                break;
            case 7:
                cout << "Current active calls: ";
                cll.traverse();
                break;
            case 8:
                cout << "Total number of active calls: " << cll.length() << endl;
                break;
            case 9:
                cout << "Exiting program.\n";
                break;
            default:
                cout << "Invalid choice! Please try again.\n";
        }
    } while (choice != 9);

    return 0;
}
