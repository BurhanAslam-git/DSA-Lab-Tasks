#include<iostream>
#include<string>
using namespace std;

struct Seat {
    int seat_Number;
    string customer_name;

    Seat(){

    }

    Seat(int s, string n) {
        this->seat_Number = s;
        this->customer_name = n;
    }
};

struct Node {
    Seat seat;     
    Node* next;   
    Node* prev;   


    Node(Seat s) {
        seat = s;
        next = nullptr;
        prev = nullptr;
    }
};

// Class for Doubly Linked List
class TicketSystem {
public:
    Node* head; 

    // Constructor to initialize an empty list
    TicketSystem() {
        head = nullptr;
    }

    // Function to insert a node at the beginning
    void insertAtBeginning(Seat s) {
        Node* newNode = new Node(s);
        newNode->next = head;

        if(head != nullptr) {
            head->prev = newNode;
        }
        newNode->prev = nullptr;
        head = newNode;
    }

    // Function to insert a node at the end
    void insertAtEnd(Seat s) {
        Node* newNode = new Node(s);
        if(head == nullptr) {
            insertAtBeginning(s);
            return;
        }
        Node* temp = head;
        while(temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode;
        newNode->prev = temp;
        newNode->next = nullptr;
    }

    // Function to insert at specific position.
    void insertAtPosition(Seat s, int p) {
        if(p < 1) return;
        if(p == 1) {
            insertAtBeginning(s);
            return;
        }
        Node* newNode = new Node(s);
        int i = 1;
        Node* temp = head;
        while(temp->next != nullptr && i < p - 1) {
            temp = temp->next;
            ++i;
        }
        
        newNode->next = temp->next;
        newNode->prev = temp;
        temp->next = newNode;
    }

    // Function to delete a node from the beginning
    void deleteFromBeginning() {
        if(head == nullptr) {
            cout << "List is Empty!" << endl;
            return;
        }
        Node* temp = head;
        head = head->next;
        if(head != nullptr) {
            head->prev = nullptr;
        }
        delete temp;
    }

    // Function to delete a node from the end
    void deleteFromEnd() {
        if (head == nullptr) {
            cout << "List is empty!" << endl;
            return;
        }

        Node* temp = head;
        while(temp->next != nullptr) {
            temp = temp->next;
        }
        if(temp->prev != nullptr) {
            temp->prev->next = nullptr;
        }
        else {
            head = nullptr;
        }
        delete temp;
    }

    // Function to delete the node from the specific position.
    void deleteFromPosition(int p) {
        if(p < 1) return;
        if(p == 1) {
            deleteFromBeginning();
            return;
        }
        Node* temp = head;
        int i = 1;
        while(temp->next != nullptr && i < p - 1) {
            temp = temp->next;
        }
        Node* nodeToDelete = temp->next;
        if (nodeToDelete != nullptr) {
            nodeToDelete->next->prev = temp;
            temp->next = nodeToDelete->next;
            delete nodeToDelete;
        }
    }

    // Function to traverse the list from head to tail
    void traverseForward() {
        if (head == nullptr) {
            cout << "List is empty!" << endl;
            return;
        }

        Node* temp = head;
        cout << "\n-------------Traversing Forward--------------\n\n";
        while(temp != nullptr) {
            cout << "Seat Number --> " << temp->seat.seat_Number << endl;
            cout << "Customer Name --> " << temp->seat.customer_name << endl;
            temp = temp->next;
        }
        cout << endl;
    }

    // Function to traverse the list from tail to head
    void traverseBackward() {
        if (head == nullptr) {
            cout << "List is empty!" << endl;
            return;
        }

        Node* temp = head;
        while(temp->next != nullptr) {
            temp = temp->next;
        }

        cout << "\n-------------Traversing Backward--------------\n\n";
        while(temp != nullptr) {
            cout << "Seat Number --> " << temp->seat.seat_Number << endl;
            cout << "Customer Name --> " << temp->seat.customer_name << endl;
            temp = temp->prev;
        }
        cout << endl;
    }

    // Function to find the length of the Linked list.
    int findLength() {
        Node* temp = head;
        int l = 0;
        while(temp != nullptr) {
            ++l;
            temp = temp->next;
        }
        return l;
    }

    // Function to search for a particular seat
    bool search(int value) {
        Node* temp = head;
        bool isFound = false;
        while(temp != nullptr) {
            if(temp->seat.seat_Number == value) {
                isFound = true;
                break;
            }
            temp = temp->next;
        }
        return isFound;
    }

    // Function to search for a specific customer
    bool searchByName(string name) {
        Node* temp = head;
        bool isFound = false;
        while(temp != nullptr) {
            if(temp->seat.customer_name == name) {
                isFound = true;
                break;
            }
            temp = temp->next;
        }
        return isFound;
    }
};

int main() {
    TicketSystem ticket;
    int choice, seatNumber, position;
    string name;

    do {
        cout << "\nMovie Ticket Booking System\n";
        cout << "1. Display all booked seats (Forward and Reverse)\n";
        cout << "2. Find the total number of booked seats\n";
        cout << "3. Book a seat\n";
        cout << "4. Cancel a booking\n";
        cout << "5. Search for a specific seat\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch(choice) {
            case 1: 
                ticket.traverseForward();
                ticket.traverseBackward();
                break;
            case 2: 
                cout << "Total booked seats: " << ticket.findLength() << endl;
                break;
            case 3:
                cout << "Enter seat number: ";
                cin >> seatNumber;
                cout << "Enter customer name: ";
                cin.ignore();
                getline(cin, name);
                cout << "Choose position to book (1 for beginning, 2 for end, 3 for specific position): ";
                int bookChoice;
                cin >> bookChoice;
                if (bookChoice == 1) {
                    ticket.insertAtBeginning(Seat(seatNumber, name));
                } else if (bookChoice == 2) {
                    ticket.insertAtEnd(Seat(seatNumber, name));
                } else if (bookChoice == 3) {
                    cout << "Enter position to book: ";
                    cin >> position;
                    ticket.insertAtPosition(Seat(seatNumber, name), position);
                }
                break;
            case 4:
                cout << "Choose cancellation option:\n";
                cout << "1. From beginning\n2. From end\n3. From specific position\n";
                int cancelChoice;
                cin >> cancelChoice;
                if (cancelChoice == 1) {
                    ticket.deleteFromBeginning();
                } else if (cancelChoice == 2) {
                    ticket.deleteFromEnd();
                } else if (cancelChoice == 3) {
                    cout << "Enter position to cancel: ";
                    cin >> position;
                    ticket.deleteFromPosition(position);
                }
                break;
            case 5:
                cout << "Search by:\n1. Seat Number\n2. Customer Name\n";
                int searchChoice;
                cin >> searchChoice;
                if (searchChoice == 1) {
                    cout << "Enter seat number to search: ";
                    cin >> seatNumber;
                    if (ticket.search(seatNumber)) {
                        cout << "Seat number " << seatNumber << " found!" << endl;
                    } else {
                        cout << "Seat number " << seatNumber << " not found!" << endl;
                    }
                } else if (searchChoice == 2) {
                    cout << "Enter customer name to search: ";
                    cin.ignore();
                    getline(cin, name);
                    if (ticket.searchByName(name)) {
                        cout << "Customer " << name << " found!" << endl;
                    } else {
                        cout << "Customer " << name << " not found!" << endl;
                    }
                }
                break;
            case 6:
                cout << "Exiting...\n";
                break;
            default:
                cout << "Invalid choice! Please try again.\n";
        }
    } while(choice != 6);

    return 0;
}
