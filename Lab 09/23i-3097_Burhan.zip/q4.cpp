#include <iostream>
#include <stack>
#include <sstream>
using namespace std;

int evaluatePostfix(string expression) {
    stack<int> s;
    stringstream ss(expression);
    string token;
    
    while (ss >> token) {
        if (isdigit(token[0])) {
            s.push(stoi(token));
        } else {
            if (s.size() < 2) {
                cout << "Invalid expression\n";
                return -1;
            }
            int b = s.top(); s.pop();
            int a = s.top(); s.pop();
            
            switch (token[0]) {
                case '+': s.push(a + b); break;
                case '-': s.push(a - b); break;
                case '*': s.push(a * b); break;
                case '/': 
                    if (b == 0) {
                        cout << "Error: Division by zero\n";
                        return -1;
                    }
                    s.push(a / b);
                    break;
                default:
                    cout << "Invalid operator\n";
                    return -1;
            }
        }
    }
    return s.size() == 1 ? s.top() : -1;
}

int main() {
    string expression;
    cout << "Enter a postfix expression: ";
    getline(cin, expression);
    
    int result = evaluatePostfix(expression);
    if (result != -1) {
        cout << "Result: " << result << "\n";
    }
    return 0;
}