#include<iostream>
using namespace std;

int findPrimSum(int** ptr, int dim){
    int sum = 0;
    for(int i=0; i<dim; ++i){
        for(int j=0; j<dim; ++j){
            if(i == j){
                sum += ptr[i][j];
            }
        }
    }
    return sum;

}

int findSecSum(int** ptr, int dim){
    int sum = 0;
    for(int i=0; i<dim; ++i){
        for(int j=0; j<dim; ++j){
                if((i+j == dim - 1)){
                     sum += ptr[i][j];
                }            
        }
    }
    return sum;

}


int main(){
    int dim;
    cout << "Enter the dimenstion (rows == cols) : "; cin >> dim;
    while(dim <= 0){
        cout << "Invalid \n Enter agian : "; cin >> dim;
    }
    int** ptr = new int*[dim];
    for(int i=0; i<dim; ++i){
        ptr[i] = new int[dim];
    }

    // inputting from the user;
    for(int i=0; i<dim; ++i){
        for(int j=0; j<dim; ++j){
            cout << "Enter Element at " << i+1 << " and " << j+1 << " : ";
            cin >> ptr[i][j];
        }
    }

    // displaying the matrix
    for(int i=0; i<dim; ++i){
        for(int j=0; j<dim; ++j){
            cout << ptr[i][j] << "  ";
        }
        cout << endl;
    }

    cout << "Primary Sum is : " << findPrimSum(ptr,dim) << endl;
    cout << "Secondary Sum is : " << findSecSum(ptr,dim) << endl;
    return 0;
}