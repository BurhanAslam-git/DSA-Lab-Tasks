#include<iostream>
using namespace std;

int findMaxRowSum(int** &ptr, int rows, int cols){
    int MaxRowSum = 0;
    int currentRowSum = 0;
    for(int i=0; i<rows; ++i){
        for(int j=0; j<cols; ++j){
            currentRowSum += ptr[i][j];
        }
        MaxRowSum = currentRowSum;
        if(currentRowSum > MaxRowSum){
            MaxRowSum = currentRowSum;
        }
        currentRowSum = 0;
     
    }
    return MaxRowSum;

}

int findMaxColSum(int** &ptr, int rows, int cols){
    int MaxColSum = 0;
    int currentColSum = 0;
    for(int i=0; i<cols; ++i){
        for(int j=0; j<rows; ++j){
            currentColSum += ptr[j][i];
        }

        MaxColSum = currentColSum;
        if(currentColSum > MaxColSum){
            MaxColSum = currentColSum;
        }
        currentColSum = 0;
     
    }
    return MaxColSum;

}

int main(){
    int** ptr = nullptr;
    int rows, cols;
    cout << "\nEnter the number of rows : "; cin >> rows;
    cout << "\nEnter the number of cols : "; cin >> cols;
    ptr = new int*[rows];
    for(int i=0; i<rows; ++i){
        ptr[i] = new int[cols];
    }

    // inputting values from the user.
    for(int i=0; i<rows; ++i){
        for(int j=0; j<cols; ++j){
            cout << "Enter Element at row " << i+1 << " column " << j+1 << " : ";
            cin >> ptr[i][j];
        }
    }

    cout << "Maximum Row Sum is : " << findMaxRowSum(ptr,rows,cols) << endl;
    cout << "Maximum Col Sum is : " << findMaxColSum(ptr,rows,cols) << endl;

    return 0;
}