#include<iostream>
using namespace std;

bool checkIdentity(int** ptr, int dim){
    bool c1 = false;
    bool c2 = false;

    // checking the first condtion.
    for(int i=0; i<dim; ++i){
        for(int j=0; j<dim; ++j){
            if(i == j){
                if(ptr[i][j] != 1){
                    c1 = false;
                }
                else if(ptr[i][j] == 1){
                    c1 = true;
                }
                else{
                    continue;
                }
            }
        }
    }

     // checking the second condtion.
        for(int i=0; i<dim; ++i){
        for(int j=0; j<dim; ++j){
            if(i != j){
                if(ptr[i][j] != 0){
                    c2 = false;
                    break;
                }
                else if(ptr[i][j] == 0){
                    c2 = true;
                }
                else{
                    continue;
                }
            }
        }
        if(!c2){
            break;
        }
    }

    if(c1 && c2){
        return true;
    }
    else{
        return false;
    }

}

int main(){
    int dim;
    cout << "Enter the dimenstion (rows == cols) : "; cin >> dim;
    while(dim <= 0){
        cout << "Invalid \n Enter agian : "; cin >> dim;
    }
    int** ptr = new int*[dim];
    for(int i=0; i<dim; ++i){
        ptr[i] = new int[dim];
    }

    // inputting from the user;
    for(int i=0; i<dim; ++i){
        for(int j=0; j<dim; ++j){
            cout << "Enter Element at " << i+1 << " and " << j+1 << " : ";
            cin >> ptr[i][j];
        }
    }

    // displaying the matrix
    for(int i=0; i<dim; ++i){
        for(int j=0; j<dim; ++j){
            cout << ptr[i][j] << "  ";
        }
        cout << endl;
    }

    if(checkIdentity(ptr,dim)){
        cout << "Matrix is Identity !";
    }
    else{
        cout << "Matrix is NOT Indentity !";
    }
    return 0;
}