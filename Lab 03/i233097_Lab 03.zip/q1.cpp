#include <iostream>
using namespace std;

void gettingValues(int** ptr, int numProd) {
    for (int i = 0; i < numProd; ++i) {
        cout << "Enter the Quantity of Product " << i + 1 << ": ";
        cin >> ptr[i][0];
        cout << "Enter the Price of Product " << i + 1 << ": ";
        cin >> ptr[i][1];
    }
}

void accessElement(int** ptr, int numProd, int id) {
    if (id < 1 || id > numProd) {
        cout << "Product Not Found!\n";
        return;
    }
    cout << "Product Found!\n";
    cout << "Quantity: " << ptr[id - 1][0] << endl;
    cout << "Price: " << ptr[id - 1][1] << endl;
}

void insertElement(int**& ptr, int& numProd) {
    int newQty, newPrice;
    cout << "Enter Quantity for New Product: ";
    cin >> newQty;
    cout << "Enter Price for New Product: ";
    cin >> newPrice;

    int** newPtr = new int*[numProd + 1];
    for (int i = 0; i < numProd; ++i) {
        newPtr[i] = ptr[i]; 
    }

    newPtr[numProd] = new int[2];
    newPtr[numProd][0] = newQty;
    newPtr[numProd][1] = newPrice;

    delete[] ptr;
    ptr = newPtr;
    numProd++;

    cout << "Item Inserted Successfully!\n\n";
}

void deleteElement(int**& ptr, int& numProd, int id) {
    if (id < 1 || id > numProd) {
        cout << "Invalid Product ID!\n";
        return;
    }

    int** newPtr = new int*[numProd - 1];
    int newIndex = 0;

    for (int i = 0; i < numProd; ++i) {
        if (i != (id - 1)) {
            newPtr[newIndex++] = ptr[i];
        } else {
            delete[] ptr[i];
        }
    }

    delete[] ptr;
    ptr = newPtr;
    numProd--;

    cout << "Product Deleted Successfully!\n";
}

void updateElement(int** ptr, int numProd, int id) {
    if (id < 1 || id > numProd) {
        cout << "Invalid Product ID!\n";
        return;
    }

    int choice;
    cout << "What would you like to update?\n";
    cout << "1. Quantity\n";
    cout << "2. Price\n";
    cout << "Enter your choice: ";
    cin >> choice;

    if (choice == 1) {
        cout << "Enter new quantity: ";
        cin >> ptr[id - 1][0];
        cout << "Quantity updated successfully!\n";
    } else if (choice == 2) {
        cout << "Enter new price: ";
        cin >> ptr[id - 1][1];
        cout << "Price updated successfully!\n";
    } else {
        cout << "Invalid choice! Update operation canceled.\n";
    }
}

void displayInventory(int** ptr, int numProd) {
    if (numProd == 0) {
        cout << "Inventory is empty!\n";
        return;
    }

    for (int i = 0; i < numProd; ++i) {
        cout << "Product #" << i + 1 << ":\n";
        cout << "Quantity: " << ptr[i][0] << endl;
        cout << "Price: " << ptr[i][1] << endl;
        cout << "-----------------\n";
    }
}

int totalInvValue(int** ptr, int numProd) {
    int totalValue = 0;
    for (int i = 0; i < numProd; ++i) {
        totalValue += ptr[i][0] * ptr[i][1];
    }
    return totalValue;
}

int main() {
    int** ptr = nullptr;
    int numProd;

    cout << "Enter the total number of products: ";
    cin >> numProd;

    while (numProd <= 0) {
        cout << "Invalid input! Enter again: ";
        cin >> numProd;
    }

    ptr = new int*[numProd];
    for (int i = 0; i < numProd; ++i) {
        ptr[i] = new int[2];
    }

    gettingValues(ptr, numProd);

    int choice;
    do {
        cout << "\n===== INVENTORY MANAGEMENT MENU =====\n";
        cout << "1. Display Inventory\n";
        cout << "2. Search Product by ID\n";
        cout << "3. Insert New Product\n";
        cout << "4. Delete a Product\n";
        cout << "5. Update a Product\n";
        cout << "6. Calculate Total Inventory Value\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                displayInventory(ptr, numProd);
                break;
            case 2: {
                int id;
                cout << "Enter Product ID to Search: ";
                cin >> id;
                accessElement(ptr, numProd, id);
                break;
            }
            case 3:
                insertElement(ptr, numProd);
                break;
            case 4: {
                int id;
                cout << "Enter Product ID to Delete: ";
                cin >> id;
                deleteElement(ptr, numProd, id);
                break;
            }
            case 5: {
                int id;
                cout << "Enter Product ID to Update: ";
                cin >> id;
                updateElement(ptr, numProd, id);
                break;
            }
            case 6:
                cout << "Total Inventory Value: " << totalInvValue(ptr, numProd) << endl;
                break;
            case 7:
                cout << "Exiting Program...\n";
                break;
            default:
                cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 7);

    // Cleanup
    for (int i = 0; i < numProd; ++i) {
        delete[] ptr[i];
    }
    delete[] ptr;

    return 0;
}
