#include <iostream>
using namespace std;

class MatrixOperations {
private:
    int matrix[3][3];   

public:
    MatrixOperations() { // default constructor.
        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                matrix[i][j] = 0;
            }
        }
    }

    void initializeValues() {
        cout << "Enter values for the 3x3 matrix:\n";
        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                cout << "Enter Element at "<< i+1 << " and " << j+1 << " : ";
                cin >> matrix[i][j];
            }
        }
    }

    void printMatrix() {
        cout << "Matrix:\n";
        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                cout << matrix[i][j] << " ";
            }
            cout << endl;
        }
    }

    void scalarMultiply(int scalar) {
        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                matrix[i][j] *= scalar;
            }
        }
    }

    void transpose() {
        int temp[3][3];
        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                temp[j][i] = matrix[i][j]; 
            }
        }

        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                matrix[i][j] = temp[i][j];
            }
        }
    }

    void addMatrix(int otherMatrix[3][3]) {
        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                matrix[i][j] += otherMatrix[i][j];
            }
        }
    }
};

int main() {
    MatrixOperations mat;
    int choice, scalar;
    int otherMatrix[3][3];

    while(true) {
        cout << "\nMatrix Operations Menu:\n";
        cout << "1. Initialize Matrix\n";
        cout << "2. Print Matrix\n";
        cout << "3. Scalar Multiplication\n";
        cout << "4. Transpose\n";
        cout << "5. Add another Matrix\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch(choice) {
            case 1:
                mat.initializeValues();
                break;
            case 2:
                mat.printMatrix();
                break;
            case 3:
                cout << "Enter a scalar value to multiply the matrix: ";
                cin >> scalar;
                mat.scalarMultiply(scalar);
                cout << "After Scalar Multiplication ";
                mat.printMatrix();
                break;
            case 4:
                mat.transpose();
                cout << "After Transpose ";
                mat.printMatrix();
                break;
            case 5:
                cout << "Enter values for another 3x3 matrix to add:\n";
                for(int i = 0; i < 3; i++) {
                    for(int j = 0; j < 3; j++) {
                        cin >> otherMatrix[i][j];
                    }
                }
                mat.addMatrix(otherMatrix);
                cout << "After Addition ";
                mat.printMatrix();
                break;
            case 6:
                cout << "Exiting...\n";
                return 0;
            default:
                cout << "Invalid choice! Please try again.\n";
        }
    }

    return 0;
}
