#include<iostream>
using namespace std;

void insertionSort(int* ptr, int n){
    int swaps =0, comp = 0;
    for(int i=0; i<=n-1; ++i){
        ++comp;
        int j = i;
        while(j > 0 && ptr[j-1] < ptr[j]){
            ++swaps;
            swap(ptr[j-1], ptr[j]);
            j--;
        }
    }

    cout << "\n---------------SORTED ARRAY IN DESCENDING ORDER---------------\n";
    for(int i=0; i<n; ++i){
        cout << ptr[i] << "  ";
    }

    cout << "\n\nNumber of Swaps Made is ---> " << swaps << endl;
    cout << "Number of Comparisons Made is ---> " << comp << endl;
    cout << endl;

}


int main()
{
    int n;
    cout << "\nEnter the number of participants : "; cin >> n;
    while(n <= 0){
        cout << "Invalid \n Enter again : "; cin >> n;
    }

    int* ptr = new int[n];
    for(int i=0; i<n; ++i)
    {
        cout << "Enter Scores " << i+1 << " : ";
        cin >> *(ptr + i);
    }

    insertionSort(ptr,n);
    

    return 0;
}