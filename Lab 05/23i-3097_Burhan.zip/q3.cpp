#include <iostream>
#include<string>
using namespace std;


class Product{
    public:
        int id;
        string name;
        double priceValue;
        int numProducts = 0;
    public:

        void assignProd(int n){
            this->numProducts = n;
        }

        

};


void display(double* ptr, Product* p, int n){
    cout << "Total Number of products ---> " << n << endl;
    for(int i=0; i<n; ++i)
    {
        cout << "\n----------Product Details--------------\n";
        cout << "Product Name ---> " << p[i].name << endl;
        cout << "Product Id ---> " << p[i].id << endl;
        cout << "Product Price Value---> " << ptr[i] << endl;
    }
 
    
}


void selectionSort(double* ptr, int n)
{
    int min;
    int swaps =0, comp = 0;
    for(int i=0; i< n-1; ++i){
        min = i;
        ++comp;
        for(int j=i; j<= n-1; ++j){
            if(ptr[j] < ptr[min]){
                min = j; // update minimun
            }
        }
        swap(ptr[i], ptr[min]);
        ++swaps;
    }
    cout << "\nSORTED ARRAY\n";
    for(int i=0; i<n; ++i){
        cout << ptr[i] << "  ";
    }

    cout << "\nTotal number of swaps is ----> " << swaps << endl;
    cout << "Total number of Comparisons is ----> " << comp << endl;

    cout << endl;
}




int main()
{
    int n;
    cout << "\nEnter the number of Products : ";
    cin >> n;
    while (n <= 0)
    {
        cout << "Invalid \n Enter again : ";
        cin >> n;
    }

    double* ptr = new double[n];


    Product* p = new Product[n];
    p->assignProd(n);

    // Inputting values from the user.
    for(int i=0; i<n; ++i)
    {
        cout << "Enter Product # " << i+1 << " details : " << endl;
        cout << "Enter Id --> ";
        cin >> p[i].id;
        cin.ignore();
        cout << "Enter Name --> " ; 
        getline(cin, p[i].name); 
        cout << "Enter Price Value --> "; 
        cin >> p[i].priceValue; 
    }


    // copying into another array of doubles.
    for(int i=0; i<n; ++i)
    {
        ptr[i] = p[i].priceValue;
    }


    selectionSort(ptr,n);
    display(ptr,p,n);

    return 0;
}