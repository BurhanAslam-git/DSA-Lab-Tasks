#include <iostream>
using namespace std;

void bubbleSort(double *ptr, int n)
{
    int swaps = 0, comp = 0;
    double fast = 0.0;
    double slow = 0.0;

    // optimized time complexity reduced.
    bool isSwapped = false;
    for (int i = n - 1; i >= 1; --i)
    { // outer loop
        ++comp;
        for (int j = 0; j <= i - 1; ++j)
        { // inner loop.
            if (ptr[j] > ptr[j + 1])
            {
                ++swaps;
                swap(ptr[j], ptr[j + 1]);
                isSwapped = true;
            }
        }
        if (isSwapped == false)
        {
            break;
        }

    }


    cout << "\n---------------SORTED ARRAY IN ASCENDING ORDER---------------\n";
    for (int i = 0; i < n; ++i)
    {
        if(i == 0)
        {
            fast = ptr[i];
        }
        if(i == n-1)
        {
            slow = ptr[i];
        }
        cout << ptr[i] << "  ";
    }


    cout << "\n\nNumber of Swaps Made is ---> " << swaps << endl;
    cout << "Number of Comparisons Made is ---> " << comp << endl;

    cout << "\nFastest Reaction Time ----> " << fast << " Millisecond" << endl;
    cout << "\nSlowest Reaction Time ----> " << slow <<  " Millisecond" << endl;
    cout << endl;
}

int main()
{
    int n;
    cout << "\nEnter the number of records : ";
    cin >> n;
    while (n <= 0)
    {
        cout << "Invalid \n Enter again : ";
        cin >> n;
    }

    double *ptr = new double[n];
    for (int i = 0; i < n; ++i)
    {
        cout << "Enter Record " << i + 1 << " : ";
        cin >> *(ptr + i);
    }

    bubbleSort(ptr, n);

    return 0;
}