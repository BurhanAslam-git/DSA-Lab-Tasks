#include <iostream>
using namespace std;

class Ride {
public:
    int requestId;
    string name;
    string PickUp_location;
    string destination;
    Ride* next;

    Ride(int id = 0, string n = "", string pl = "", string des = "") {
        this->requestId = id;
        this->name = n;
        this->PickUp_location = pl;
        this->destination = des;
        next = nullptr;
    }

    void print() {
        cout << "\n----- Ride Details -----\n";
        cout << "Ride ID: " << this->requestId << endl;
        cout << "Passenger Name: " << this->name << endl;
        cout << "Pick Up Location: " << this->PickUp_location << endl;
        cout << "Destination: " << this->destination << endl;
    }
};

class Queue {
private:
    Ride* front;
    Ride* rear;
    int numItems;

public:
    Queue() {
        front = rear = nullptr;
        numItems = 0;
    }

    bool isEmpty() {
        return numItems == 0;
    }

    void enqueue(int id, string n, string pl, string des) {
        Ride* newRide = new Ride(id, n, pl, des);
        if (rear == nullptr) {
            front = rear = newRide;
        } else {
            rear->next = newRide;
            rear = newRide;
        }
        cout << "\n Ride Added Successfully!\n";
        newRide->print();
        ++numItems;
    }

    void dequeue() {
        if (isEmpty()) {
            cout << "\n No pending requests!\n";
            return;
        }
        Ride* temp = front;
        front = front->next;
        if (front == nullptr) rear = nullptr;

        cout << "\n Ride Assigned and Removed Successfully!";
        temp->print();
        delete temp;
        --numItems;
    }

    void peek() {
        if (isEmpty()) {
            cout << "\n No pending requests!\n";
            return;
        }
        cout << "\n Next Ride in Queue:";
        front->print();
    }

    void display() {
        if (isEmpty()) {
            cout << "\n No pending requests!\n";
            return;
        }
        cout << "\n Pending Ride Requests:";
        Ride* temp = front;
        while (temp != nullptr) {
            temp->print();
            temp = temp->next;
        }
    }
};

int main() {
    Queue rideQueue;

    // Adding ride requests
    rideQueue.enqueue(101, "Alice", "Downtown", "Airport");
    rideQueue.enqueue(102, "Bob", "Mall", "University");
    rideQueue.enqueue(103, "Charlie", "Station", "Home");

    // Display all pending rides
    rideQueue.display();

    // View next ride request
    rideQueue.peek();

    // Assign rides to drivers
    rideQueue.dequeue();
    rideQueue.dequeue();

    // Check pending rides
    rideQueue.display();

    // Assign the last ride
    rideQueue.dequeue();

    // Try to assign when no rides are available
    rideQueue.dequeue();

    return 0;
}
