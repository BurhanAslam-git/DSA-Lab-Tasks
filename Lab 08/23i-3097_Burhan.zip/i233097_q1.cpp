#include <iostream>
using namespace std;

class Patient {
public:
    int patientId;
    string name;
    int severity_level;

    Patient(int id = 0, string n = "", int sl = 0) {
        this->patientId = id;
        this->name = n;
        this->severity_level = sl;
    }

    void print() {
        cout << "\nPatient Name: " << name << endl;
        cout << "Patient ID: " << patientId << endl;
        cout << "Severity Level: " << severity_level << "\n" << endl;
    }
};

class Queue {
private:
    Patient *arr;
    int front, rear, size, numItems;

public:
    Queue(int c = 10) {
        size = c;
        arr = new Patient[size];
        front = rear = -1;
        numItems = 0;
    }

    ~Queue() {
        delete[] arr;
    }

    bool isFull() {
        return numItems == size;
    }

    bool isEmpty() {
        return numItems == 0;
    }

    void enqueue(int pid, string n, int level) {
        if (isFull()) {
            cout << "Queue is full. Please wait.\n";
            return;
        }
        if (isEmpty()) {
            front = rear = 0;
        } else {
            rear = (rear + 1) % size;
        }
        arr[rear] = Patient(pid, n, level);
        numItems++;
        cout << "Patient added successfully!\n";
    }

    void dequeue() {
        if (isEmpty()) {
            cout << "Queue is empty. No patients to process.\n";
            return;
        }
        cout << "Processing patient:\n";
        arr[front].print();
        front = (front + 1) % size;
        numItems--;
    }

    Patient peek() {
        if (isEmpty()) {
            cout << "Queue is empty. No patients to show.\n";
            return Patient();
        }
        return arr[front];
    }

    void displayQueue() {
        if (isEmpty()) {
            cout << "Queue is empty.\n";
            return;
        }
        cout << "\n---- Current Patients in Queue ----\n";
        for (int i = 0; i < numItems; i++) {
            arr[i].print();
        }
    }
};

int main() {
    const int numPatients = 2;
    Queue queue(numPatients);
    int id, level;
    string name;

    for (int i = 0; i < 2; ++i) {
        cout << "Enter details for Patient #" << (i + 1) << "\n";
        cout << "Enter ID: ";
        cin >> id;
        cout << "Enter Name: ";
        cin >> name;
        cout << "Enter Severity Level (1-5): ";
        cin >> level;
        while (level < 1 || level > 5) {
            cout << "Invalid severity level. Enter again: ";
            cin >> level;
        }
        queue.enqueue(id, name, level);
    }

    cout << "\nDisplaying all registered patients:\n";
    queue.displayQueue();

    cout << "\nProcessing first patient...\n";
    queue.dequeue();

    // cout << "\nNext patient in line:\n";
    // queue.peek().print();

    cout << "\nDisplaying all registered patients:\n";
    queue.displayQueue();

    queue.enqueue(3, "ali", 4);

    
    cout << "\nDisplaying all registered patients:\n";
    queue.displayQueue();

    return 0;
}